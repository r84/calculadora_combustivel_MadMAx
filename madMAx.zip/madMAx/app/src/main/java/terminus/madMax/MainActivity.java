package terminus.madMax;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.Nullable;

public class MainActivity extends Activity{

    public static final String EXTRA_VALOR_GASOLINA = "VALOR_GASOLINA";
    public static final String EXTRA_VALOR_ETANOL = "VALOR_ETANOL";

    public static final String EXTRA_CONSUMO_GASOLINA = "CONSUMO_GASOLINA";
    public static final String EXTRA_CONSUMO_ETANOL = "CONSUMO_ETANOL";


    private Button botaoCalcular;
    private EditText valorGasolina;
    private EditText valorEtanol;
    private EditText consumoGasolina;
    private EditText consumoEtanol;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState){
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main); // classe R é de resources, pasta res

        valorGasolina = findViewById(R.id.valorLitroGasolina);
        valorEtanol = findViewById(R.id.valorLitroEtanol);
        consumoGasolina = findViewById(R.id.consumoGasolina);
        consumoEtanol = findViewById(R.id.consumoEtanol);
        botaoCalcular = findViewById(R.id.botaoCalcular);

        botaoCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                changeToResultScreen();
            }
        });
    }

    private void changeToResultScreen() {
        Intent intent = new Intent(this, ResultActivity.class);

        EditText valorGasolina = (EditText) findViewById(R.id.valorGasolina);
        EditText valorEtanol = (EditText) findViewById(R.id.valorEtanol);
        EditText consumoGasolina = (EditText) findViewById(R.id.consumoGasolina);
        EditText consumoEtanol = (EditText) findViewById(R.id.consumoEtanol);

        intent.putExtra(EXTRA_VALOR_GASOLINA, valorGasolina.getText().toString());
        intent.putExtra(EXTRA_VALOR_ETANOL, valorEtanol.getText().toString());
        intent.putExtra(EXTRA_CONSUMO_GASOLINA, consumoGasolina.getText().toString());
        intent.putExtra(EXTRA_CONSUMO_ETANOL, consumoEtanol.getText().toString());


        startActivity(intent);
    }

}
