package terminus.madMax;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;


public class ResultActivity extends Activity {

        @Override
        protected void onCreate(@Nullable Bundle savedInstanceState) {

            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_result);
            Intent intent = getIntent();
            String valorGasolina = intent.getStringExtra(MainActivity.EXTRA_VALOR_GASOLINA);
            String valorEtanol = intent.getStringExtra(MainActivity.EXTRA_VALOR_ETANOL);
            String consumoGasolina = intent.getStringExtra(MainActivity.EXTRA_CONSUMO_GASOLINA);
            String consumoEtanol = intent.getStringExtra(MainActivity.EXTRA_CONSUMO_ETANOL);

            TextView resultadoView = findViewById(R.id.textoResultado);
            TextView valorLitroGasolina = findViewById(R.id.valorLitroGasolina);
            TextView valorLitroEtanol = findViewById(R.id.valorLitroEtanol);
            TextView kmPorLitroGasolina = findViewById(R.id.kmPorLitroGasolina);
            TextView kmPorLitroEtanol = findViewById(R.id.kmPorLitroEtanol);
            TextView relacaoEtanolGasolina = findViewById(R.id.relacaoEtanolGasolina);
            TextView gastoGasolina = findViewById(R.id.gastoGasolina);
            TextView gastoEtanol = findViewById(R.id.gastoEtanol);




            double valorGasolinaBack = Double.parseDouble(valorGasolina);
            double valorEtanolBack = Double.parseDouble(valorEtanol);
            double consumoGasolinaBack = Double.parseDouble(consumoGasolina);
            double consumoEtanolBack = Double.parseDouble(consumoEtanol);
            double resultado = valorEtanolBack / valorGasolinaBack;

            double gastoGasolinaBack = valorGasolinaBack / consumoGasolinaBack;

            double gastoEtanolBack = valorEtanolBack / consumoEtanolBack;

            valorLitroGasolina.setText(valorGasolina);
            valorLitroEtanol.setText(valorEtanol);
            kmPorLitroGasolina.setText(consumoGasolina);
            kmPorLitroEtanol.setText(consumoEtanol);
            relacaoEtanolGasolina.setText(String.format("%.2f",resultado));
            gastoGasolina.setText(String.format("%.2f",gastoGasolinaBack));
            gastoEtanol.setText(String.format("%.2f",gastoEtanolBack));




            if(resultado >= 0.7){
                resultadoView.setText("Abasteça com Gasolina!");
            } else {
                resultadoView.setText("Abasteça com Etanol!");
            }

            Button backButton = findViewById(R.id.botaoVoltar);

            backButton.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View view){
                    ResultActivity.super.onBackPressed();
                }
            });
        }
}
